package bonus;

public interface ToDoRepository  {
	ToDo save(ToDo todo);
}