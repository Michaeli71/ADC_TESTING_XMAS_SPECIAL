package exercises.part5_6;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex04_ChatEngine
{
    private final MessageSender messageSender;

    public Ex04_ChatEngine(final MessageSender messageSender)
    {
        this.messageSender = messageSender;
    }

    public String say(final String message)
    {
        return messageSender.send(message);
    }
}
