package exercises.part5_6;

import java.util.List;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex05_PersonService 
{
    private final PersonDao dao;

    public Ex05_PersonService(final PersonDao dao) 
    {
        this.dao = dao;
    }

    public List<Person> findAll() 
    {
        return dao.findAll();
    }

    public Person findById(int id) 
    {
        return dao.findById(id);
    }
}