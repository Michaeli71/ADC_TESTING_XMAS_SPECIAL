package exercises.part7_8;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.MonthDay;
import java.util.Arrays;
import java.util.List;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class FahrpreisRechner 
{
	public static int fahrpreis(int grundpreis,
			int preisProKM,
			int streckeInKM,
			boolean istNachtfahrt,
			boolean mitGepäck,
			boolean amFeiertag)
	{
		double preis = grundpreis + preisProKM * streckeInKM;
		
		if (streckeInKM > 50)
			preis *= 0.9;
		else if (streckeInKM > 10)
			preis *= 0.95;

		if (istNachtfahrt)
			preis *= 1.2;
		if (mitGepäck)
			preis += 3_00;
		if (amFeiertag)
            preis *= 1.1;
		
		return (int)(preis + 0.5);
	}	
	
	public static boolean isSunday(LocalDate day)
	{
	    return day.getDayOfWeek() == DayOfWeek.SUNDAY;
	}
	
	public static boolean isFeiertag(LocalDate day)
    {
        final MonthDay currentMonthDay = MonthDay.of(day.getMonth(), day.getDayOfMonth());
        
        final List<MonthDay> predefinesFeiertage = Arrays.asList(
                                           MonthDay.of(1, 1),
                                           MonthDay.of(5, 1),
                                           MonthDay.of(8, 1),
                                           MonthDay.of(25, 12),
                                           MonthDay.of(26, 12)
        );
        
        return predefinesFeiertage.contains(currentMonthDay); 
    }
}
