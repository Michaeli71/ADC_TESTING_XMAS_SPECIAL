package exercises.part7_8;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex02_Student
{
    private int    id;
    private String name;
    private int    score;

    public Ex02_Student(int id, String name, int score)
    {
        this.id = id;
        this.name = name;
        this.score = score;
    }

    public int getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public int getScore()
    {
        return score;
    }
}