package exercises.part3;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex07_DiscountCalculator 
{
    // ACHTUNG: Enthält bewusst ein paar kleine Fehler
	public int calcDiscount(final int count)
	{
		if (count < 50)
			return 0;
		if (count > 50 && count < 1000)
			return 4;
		if (count > 1000)
			return 7;

		throw new IllegalStateException("programming problem: should never " +
	                  "reach this line. value " + count + " is not handled!");
	}
}