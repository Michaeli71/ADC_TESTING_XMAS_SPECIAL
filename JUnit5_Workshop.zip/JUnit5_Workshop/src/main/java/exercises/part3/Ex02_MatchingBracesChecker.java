package exercises.part3;

import java.util.Stack;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex02_MatchingBracesChecker
{
    // ACHTUNG: Enthält bewusst ein paar kleine Fehler
    static boolean checkMatchingBraces(final String input)
    {        
        final Stack<Character> openingParens = new Stack<>(); 
        
        for (int i = 0; i < input.length(); i++)
        {
            char currentChar = input.charAt(i);
            if (isOpeningParenthesis(currentChar))
            {
                openingParens.push(currentChar);
            }
            else if (isClosingParenthesis(currentChar))
            {
                char lastOpeningParens = openingParens.pop();
                
                if (!isMatchingParenthesisPair(lastOpeningParens, currentChar))
                {
                    // mismatch in parenthesis
                    return false;
                }
            }
            else
            {
                // invalid char
                return false;
            }                
        }        
        
        return true;
    }

    // Helpers
    static boolean isOpeningParenthesis(final char ch)
    {
        return ch == '(' || ch == '[' || ch == '{';
    }
    
    static boolean isClosingParenthesis(final char ch)
    {
        return ch == ')' || ch == ']' || ch == '}';
    }
    
    static boolean isMatchingParenthesisPair(final char opening, final char closing)
    {
        return (opening == '(' && closing == ')') ||
               (opening == '[' && closing == ']') ||
               (opening == '{' && closing == '}');
    }
}
