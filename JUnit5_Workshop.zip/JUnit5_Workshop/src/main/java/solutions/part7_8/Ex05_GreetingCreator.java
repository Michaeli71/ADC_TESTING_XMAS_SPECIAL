package solutions.part7_8;

import java.time.LocalTime;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex05_GreetingCreator
{
    public String createGreeting(LocalTime time)
    {
        String message = "Good ";
   
        // Korrektur 3: Sekunde nach Mitternacht inklusive    
        if (time.isAfter(LocalTime.of(0, 0, 0)) && time.isBefore(LocalTime.of(12, 0, 0)))
        {
            message += "Morning";
        }
        // Korrektur 1
        // ###########
        // Korrektur 2: 12 Uhr inklusive
        else if (time.isAfter(LocalTime.of(11, 59, 59)) && time.isBefore(LocalTime.of(18, 0, 0)))
        {
            message += "Afternoon";
        }
        // Korrektur 2: 18 Uhr inklusive
        // Korrektur 3: 24 Uhr inklusive      
        // Tools erkennen Ääuivalenz beider Anweisungen hier nicht
        else if (time.isAfter(LocalTime.of(17, 59, 59)) || time.equals(LocalTime.of(0, 0, 0)))
        //else
        {
            message += "Evening";
        }
        
        return message;
    }
}
