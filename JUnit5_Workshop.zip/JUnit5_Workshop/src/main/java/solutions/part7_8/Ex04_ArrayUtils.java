package solutions.part7_8;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex04_ArrayUtils
{
    // needed for 100 % Test Coverage
    private Ex04_ArrayUtils()
    {        
    }
    
    public static int indexOf(final int[] values, final int searchFor)
    {
        if (values == null)
        {
            throw new IllegalArgumentException("Array is null");
        }
        
        int index = -1;
        for (int i = 0; i < values.length; i++)
        {
            if (values[i] == searchFor)
            {
                index = i;
                break;
            }
        }
        return index;
    }
}
