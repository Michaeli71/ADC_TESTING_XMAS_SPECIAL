package domain;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Person
{
    // just for the example
    public final String    name;

    public final LocalDate dateOfBirth;

    public final String    homeTown;
    
    public final String    hobby;

    public Person(String name, LocalDate dateOfBirth, String homeTown)
    {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.homeTown = homeTown;
        this.hobby = "N/A";
    }
    
    public Person(String name, LocalDate dateOfBirth, String homeTown, String hobby)
    {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.homeTown = homeTown;
        this.hobby = hobby;
    }

    public String getName()
    {
        return name;
    }

    public LocalDate getDateOfBirth()
    {
        return dateOfBirth;
    }

    public String getHomeTown()
    {
        return homeTown;
    }

    public String getHobby()
    {
        return hobby;
    }


    @Override
    public String toString()
    {
        return "Person [name=" + name + ", dateOfBirth=" + dateOfBirth + ", homeTown=" + homeTown + ", hobby=" + hobby
               + "]";
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(dateOfBirth, homeTown, name);
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        
        Person other = (Person) obj;
        return Objects.equals(dateOfBirth, other.dateOfBirth) && Objects.equals(homeTown, other.homeTown)
               && Objects.equals(name, other.name);
    }
}