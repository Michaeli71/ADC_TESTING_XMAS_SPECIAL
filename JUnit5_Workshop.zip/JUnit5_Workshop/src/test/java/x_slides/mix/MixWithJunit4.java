package x_slides.mix;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MixWithJunit4
{
    @Test
    //@Disabled
    void testJunit5()
    {
        assertEquals("JUnit5", "JUnit5");
    }

    @org.junit.Test
    //@Ignore
    public void testJunit4()
    {
        org.junit.Assert.assertEquals("JUnit5", "JUnit5");
    }
}
