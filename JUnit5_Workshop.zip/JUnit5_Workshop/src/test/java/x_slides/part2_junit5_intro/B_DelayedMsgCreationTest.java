package x_slides.part2_junit5_intro;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class B_DelayedMsgCreationTest
{
    @Test
    void withMessageSimple()
    {
        String expected = "Tim";

        // complicated msg is always calculated independently of comparison
        assertEquals(expected, "Tim", complicatedCalculation("Hint"));
        assertEquals(expected, "ALWAYS", complicatedCalculation("Hint"));
    }

    @Test
    void withMessageDelayed()
    {
        String expected = "Tim";
        
        // complicated msg is only calculated if comparison fails
        assertEquals(expected, "Tim", () -> complicatedCalculation("Hint"));
        assertEquals(expected, "XYZ", () -> complicatedCalculation("Hint"));
    }
    
    private String complicatedCalculation(String info)
    {
        try
        {
            Thread.sleep(1_000);
        }
        catch (InterruptedException ignored)
        {
        }
        return info + info;
    }
}
