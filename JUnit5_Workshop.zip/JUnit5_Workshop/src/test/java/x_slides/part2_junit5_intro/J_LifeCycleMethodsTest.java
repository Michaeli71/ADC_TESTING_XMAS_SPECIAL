package x_slides.part2_junit5_intro;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class J_LifeCycleMethodsTest
{
    @BeforeAll
    static void setupServer()
    {
        System.out.println("setupServer");
    }

    @BeforeEach
    void prepareDatabase()
    {
        System.out.println("prepareDatabase");
    }

    @Test
    void simpleTest()
    {
        System.out.println("simpleTest");
    }

    @Test
    void anotherTest()
    {
        System.out.println("anotherTest");
    }

    @AfterEach
    void cleanupDatabase()
    {
        System.out.println("cleanupDatabase");
    }

    @AfterAll
    static void tearDownServer()
    {
        System.out.println("tearDownServer");
    }
}