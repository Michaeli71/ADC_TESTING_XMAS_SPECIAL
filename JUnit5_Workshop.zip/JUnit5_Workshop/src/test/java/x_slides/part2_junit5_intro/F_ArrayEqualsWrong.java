package x_slides.part2_junit5_intro;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class F_ArrayEqualsWrong
{
    @Test
    void arraysCompare()
    {
        final String[] words = { "Word1", "Word2" };

        final String[] expected = { "Word1", "Word2" };

        assertEquals(expected, words);
    }

    @Test
    void nestedArraysCompare()
    {
        final String[][] nested = { { "Line1", "Word1" }, { "Line2", "Word2" } };

        final String[][] expected = { { "Line1", "Word1" }, { "Line2", "Word2" } };

        assertEquals(expected, nested);
    }
}
