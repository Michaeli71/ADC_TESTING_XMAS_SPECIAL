package x_slides.part2_junit5_intro;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@TestMethodOrder(OrderAnnotation.class)
public class K_ExecutionOrderByOrderAnnotationTest
{
    private static final StringBuilder output = new StringBuilder("");
    
    @Test
    @Order(2)
    public void secondTest() {
        output.append("b");
    }
 
    @Test
    @Order(3)
    public void thirdTest() {
        output.append("c");
    }
 
    @Test
    @Order(1)
    public void firstTest() {
        output.append("a");
    }

    @AfterAll
    public static void assertOutput()
    {
        assertEquals("abc", output.toString());
    }
}