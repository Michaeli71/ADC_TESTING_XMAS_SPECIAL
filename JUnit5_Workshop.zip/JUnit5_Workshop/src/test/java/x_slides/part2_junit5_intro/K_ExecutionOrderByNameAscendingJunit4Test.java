package x_slides.part2_junit5_intro;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class K_ExecutionOrderByNameAscendingJunit4Test
{
    private static final StringBuilder result = new StringBuilder("");
    
    @Test
    public void B_secondTest() {
        result.append("b");
    }
 
    @Test
    public void C_thirdTest() {
        result.append("c");
    }
 
    @Test
    public void A_firstTest() {
        result.append("a");
    }

    @AfterClass
    public static void assertOutput()
    {
        assertEquals("abc", result.toString());
    }
}