package x_slides.part7_testsmells;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import domain.Person;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class ConditionalLogic
{
    @Test
    void badContionalLogic()
    {
        final Person mike = new Person("Mike", LocalDate.of(1971, 2, 7), "Zürich");
        final Person otherMike = new Person("Mike", LocalDate.of(1971, 2, 7), "Kile");
                  
        assertNotNull(mike, "mike not null");
        if (mike.getHomeTown().equals("Zürich"))
        {
            assertEquals(LocalDate.of(1971, 2, 7), mike.getDateOfBirth());    
        }
        else
        {
            assertTrue(mike.equals(otherMike), "same content");
        }
    }
}
