package x_slides.part7_testsmells;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import domain.Person;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class AssertTrueForever
{
    @Test
    void assertTrueForever()
    {
        final Person mike = new Person("Mike", LocalDate.of(1971, 2, 7), "Zürich");
        final Person sameMike = mike;
        final Person otherMike = new Person("Mike", LocalDate.of(1971, 2, 7), "Zürich");
                  
        assertTrue(mike != null, "mike not null");
        assertTrue(mike == sameMike, "same obj");
        assertTrue(mike.equals(otherMike), "same content");
    }
    
    @Test
    void rightAssertsForTheJob()
    {
        final Person mike = new Person("Mike", LocalDate.of(1971, 2, 7), "Zürich");
        final Person sameMike = mike;
        final Person otherMike = new Person("Mike", LocalDate.of(1971, 2, 7), "Zürich");
                  
        assertNotNull(mike, "mike not null");
        assertSame(mike, sameMike, "same obj");
        assertEquals(mike, otherMike, "same content");   
    }
}
