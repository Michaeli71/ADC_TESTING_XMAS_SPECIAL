package x_slides.part5_6_dependencies_testability;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.util.List;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class BehavorialTestingExample
{
    public static void main(String[] args)
    {
        // Arrange
        final List<String> mockedList = mock(List.class);
        final Members members = new Members(mockedList);

        // Act
        members.registerMember("Person1");
        members.registerMember("Person2");
        members.deregisterMember("Person1");

        // Assert
        verify(mockedList).add("Person1");
        verify(mockedList).add("Person2");
        verify(mockedList).remove("Person1");
    }
}
