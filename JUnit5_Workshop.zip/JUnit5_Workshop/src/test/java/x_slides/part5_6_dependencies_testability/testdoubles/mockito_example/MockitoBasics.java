package x_slides.part5_6_dependencies_testability.testdoubles.mockito_example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class MockitoBasics {
	@Test
	public void testGreetingReturnValue() {
		// Arrange
		final Greeting greeting = Mockito.mock(Greeting.class);

		// Achtung: Reihenfolge wichtig
		when(greeting.greet(anyString())).thenReturn("Welcome to Mockito");
		when(greeting.greet("Mike")).thenReturn("Mister Mike");
		when(greeting.greet("ERROR")).thenThrow(new IllegalArgumentException());

		// Act
		final Application app = new Application(greeting);
		final String result1 = app.generateMsg("Mike");
		final String result2 = app.generateMsg("ABC");

		// Assert
		assertEquals("Mister Mike", result1);
		assertEquals("Welcome to Mockito", result2);
		assertThrows(IllegalArgumentException.class, () -> greeting.greet("ERROR")); // => Exception
	}
}
