package x_slides.part5_6_dependencies_testability.testdoubles.mockito_example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class PizzaServiceTest
{    
    @Test
    void testOrderPizza() throws Exception
    {
        // Arrange
        final SmsNotificationService notificationService = 
                                     mock(SmsNotificationService.class);
        final PizzaService pizzaService = new PizzaService(notificationService);
        
        // Act
        pizzaService.orderPizza("Diavolo");
        pizzaService.orderPizza("Surprise");
        
        final ArgumentCaptor<String> argCaptor = 
                                     ArgumentCaptor.forClass(String.class);
        verify(notificationService, times(2)).send(argCaptor.capture());
        
	    final List<String> allValues = argCaptor.getAllValues();
		var expected = List.of(PizzaService.createNotificationMsg("Diavolo"),
			   	               PizzaService.createNotificationMsg("Surprise"));
		
		assertEquals(expected, allValues);
    }
}