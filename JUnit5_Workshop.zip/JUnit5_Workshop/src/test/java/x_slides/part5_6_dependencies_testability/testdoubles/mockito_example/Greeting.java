package x_slides.part5_6_dependencies_testability.testdoubles.mockito_example;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Greeting 
{
    public String greet(final String name) 
    {
        return "Hello " + name;
    }
}