package x_slides.part3_junit5_advanced;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class C_NextedTests
{
    @Nested
    @DisplayName("Given inputs of 7 and 2")
    class PredefinedValues
    {
        final int input1 = 7;

        final int input2 = 2;

        @Test
        void plus()
        {
            assertEquals(9, input1 + input2);
        }

        @Test
        void subtract()
        {
            assertEquals(5, input1 - input2);
        }

        @Test
        void multiply()
        {
            assertEquals(14, input1 * input2);
        }

        @Test
        void divide()
        {
            assertEquals(3.5, (double) input1 / input2);
        }
    }

@Nested
@DisplayName("Test Add Book Feature")
class AddFeature
{
    @Test
    void testBookNameMissing()
    {
    }

    @Nested
    @DisplayName("Test Update Book Feature")
    class UpdateFeature
    {
        @Test
        void testChangeBookName()
        {
        }
    }
}
}
