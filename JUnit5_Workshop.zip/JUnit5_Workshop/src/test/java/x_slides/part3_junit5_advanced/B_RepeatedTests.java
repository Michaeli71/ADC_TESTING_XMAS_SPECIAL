package x_slides.part3_junit5_advanced;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.TestInfo;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class B_RepeatedTests
{
    @RepeatedTest(3)
    void repeatedTest()
    {
        assertTrue(true);
    }

    @RepeatedTest(7)
    void repeatedTestWithInfo(RepetitionInfo repetitionInfo)
    {
        assertEquals(7, repetitionInfo.getTotalRepetitions());
    }

    @RepeatedTest(value = 5, name = "{displayName} {currentRepetition}/{totalRepetitions}")
    @DisplayName("Repeated! ")
    void customDisplayName(TestInfo testInfo, RepetitionInfo repetitionInfo)
    {
        int current = repetitionInfo.getCurrentRepetition();
        int total = repetitionInfo.getTotalRepetitions();

        assertEquals(testInfo.getDisplayName(), "Repeated! " + current + "/" + total);
    }
}
