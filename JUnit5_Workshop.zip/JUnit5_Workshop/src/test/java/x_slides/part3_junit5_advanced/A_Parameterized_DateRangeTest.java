package x_slides.part3_junit5_advanced;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class A_Parameterized_DateRangeTest {
	
	@ParameterizedTest(name = "validateDateRange({0} => {1}")
	@MethodSource("allCombinations")
	void validateDateRangeConstruction(LocalDate from, LocalDate to, Class<? extends Throwable> expectedException) {
	    
	    // TEST SMELL: Conditional Logic ...
		if (expectedException != null) {
			assertThrows(expectedException, () -> new DateRange(from, to));
		} else {
			assertNotNull(new DateRange(from, to));
		}
	}

	static Stream<Arguments> allCombinations() {
		return Stream.of(Arguments.of(null, LocalDate.now(), null),
				Arguments.of(LocalDate.now(), null, null),
				Arguments.of(null, null, IllegalArgumentException.class));
	}
	
	// Improvement
	
    @Test
    void testInvalidDateRangeConstruction()
    {
        assertThrows(IllegalArgumentException.class, () -> new DateRange(null, null));
    }

    @Test
    void testValidDateRangeConstruction()
    {
        assertAll(()-> assertNotNull(new DateRange(null, LocalDate.now())),
                  ()-> assertNotNull(new DateRange(LocalDate.now(), null)));
    }
    

    class DateRange {
        // one of both can be null
        LocalDate from;
        LocalDate to;

        public DateRange(LocalDate from, LocalDate to) {

            if (from == null && to == null) {
                throw new IllegalArgumentException("invalid range, two nulls");
            }

            this.from = from;
            this.to = to;
        }
    }
}