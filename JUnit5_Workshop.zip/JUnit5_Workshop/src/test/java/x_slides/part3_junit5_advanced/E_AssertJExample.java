package x_slides.part3_junit5_advanced;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.withPrecision;
//
import static org.junit.jupiter.api.Assertions.assertAll;

import java.util.AbstractMap;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class E_AssertJExample
{
    @Test
    void assertJAssertinsBasics()
    {
        String peter = "Peter";
        assertThat(peter).isEqualTo("Peter");

        assertThat(peter.isEmpty()).isFalse();
        assertThat("".isEmpty()).isTrue();

        assertThat(7.271).isEqualTo(7.2, withPrecision(0.1d));
    }

    @Test
    void assertJCollectionsBasics()
    {
        List<String> names = Arrays.asList("Tim", "Tom", "Mike");

        assertThat(names).isNotEmpty();
        assertThat(names).contains("Mike");
        assertThat(names).startsWith("Tim");

        assertAll(() -> assertThat(names).isNotEmpty(), 
                  () -> assertThat(names).contains("Mike"),
                  () -> assertThat(names).startsWith("Tim"));

        // AssertJ Variante Chaining
        assertThat(names).isNotEmpty().contains("Mike").startsWith("Tim");
    }

    @Test
    void assertJMapsBasics()
    {
        // aua Java 8 diamond, wie schön ist hier Java 9
        final Map<String, Integer> personsAgeMap = new HashMap<String, Integer>() {{
            put("Tim", 48);
            put("Tom", 7);
            put("Mike", 48);           
        }};

        assertThat(personsAgeMap).isNotEmpty().
                                    containsKey("Mike").
                                    doesNotContainKeys("Peter").
                                    // aua, wie schön ist hier Java 9
                                    contains(new AbstractMap.SimpleEntry<>("Tim", 48));
    }

}
