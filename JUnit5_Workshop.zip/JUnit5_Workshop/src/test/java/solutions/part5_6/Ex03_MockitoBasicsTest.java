package solutions.part5_6;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Comparator;
import java.util.Iterator;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@ExtendWith(MockitoExtension.class)
public class Ex03_MockitoBasicsTest
{
    @Test
    public void iterator_next_return_hello_world()
    {
        // arrange
        Iterator<String> it = Mockito.mock(Iterator.class);
        Mockito.when(it.next()).thenReturn("Hello", "World");

        // act
        String result = it.next() + " " + it.next();

        // assert
        assertEquals("Hello World", result);
    }

    @Test
    public void iterator_hasNext_return_hello_world()
    {
        // arrange
        Iterator<String> it = Mockito.mock(Iterator.class);
        Mockito.when(it.next()).thenReturn("Hello").thenReturn("JUNIT").thenReturn("PARCITIPANTS");
        Mockito.when(it.hasNext()).thenReturn(true, true, true, false);

        // act
        String result = "";
        while (it.hasNext())
        {
            result += it.next();
        }

        // assert
        assertEquals("HelloJUNITPARCITIPANTS", result);
    }

    @Test
    public void with_arguments()
    {
        Comparator<String> comp = Mockito.mock(Comparator.class);
        Mockito.when(comp.compare("Test", "TEST")).thenReturn(1);
        Mockito.when(comp.compare("ABC", "DEF")).thenReturn(-1);
        
        // act
        int result1 = comp.compare("Test", "TEST");
        int result2 = comp.compare("ABC", "DEF");
        
        // assert
        assertAll(() -> assertEquals(1, result1),
                  () -> assertEquals(-1, result2));
    }
}