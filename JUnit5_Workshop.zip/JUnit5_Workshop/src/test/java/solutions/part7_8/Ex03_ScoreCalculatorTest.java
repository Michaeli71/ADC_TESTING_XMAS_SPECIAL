package solutions.part7_8;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex03_ScoreCalculatorTest
{
    // ÄQUIVALENZKLASSEN
	
	@Test
    public void testCalcScore_Fail() throws Exception
    {
        String result = Ex03_ScoreCalculator.calcScore(25);

        assertEquals("failed", result);
    }

    @Test
    public void testCalcScore_Pass() throws Exception
    {
        String result = Ex03_ScoreCalculator.calcScore(75);

        assertEquals("passed", result);
    }

    @Test
    public void testCalcScore_PassWithDistinction() throws Exception 
    {
        String result = Ex03_ScoreCalculator.calcScore(97);
        
        assertEquals("passed with distinction", result);
    }
}
