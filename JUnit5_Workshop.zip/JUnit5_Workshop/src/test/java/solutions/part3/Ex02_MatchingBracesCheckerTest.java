package solutions.part3;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex02_MatchingBracesCheckerTest
{
    @Test
    public void testCheckMatchingBraces_Ok_1() throws Exception
    {
        String input = "()";
        assertTrue("Checking " + input, Ex02_MatchingBracesChecker.checkMatchingBraces(input));
    }

    @Test
    public void testCheckMatchingBraces_Ok_2() throws Exception
    {

        String input = "()[]{}";
        assertTrue("Checking " + input, Ex02_MatchingBracesChecker.checkMatchingBraces(input));
    }

    @Test
    public void testCheckMatchingBraces_Ok_3() throws Exception
    {
        String input = "[((()[]{}))]";
        assertTrue("Checking " + input, Ex02_MatchingBracesChecker.checkMatchingBraces(input));
    }

    // Variante 1
    @Test
    public void testCheckMatchingBracesAllWrong() throws Exception
    {
        String inputWrong1 = "(()";
        String inputWrong2 = "((})";
        String inputWrong3 = "(()}";
        String inputWrong4 = ")()(";
        String inputWrong5 = "()((";
        String inputWrong6 = "()A(";
        List<String> inputs = Arrays.asList(inputWrong1, inputWrong2, inputWrong3, inputWrong4, inputWrong5, inputWrong6);

        for (String current : inputs)
        {
            assertFalse("Checking " + current, Ex02_MatchingBracesChecker.checkMatchingBraces(current));
        }
    }

    // Variante 2: Deckt Fehler direkt auf und vermeidet aufwendige Tests	
    @ParameterizedTest
    @ValueSource(strings = { "(()", "((})", "(()}", ")()(", "()((", "()A(" })
    public void testCheckMatchingBracesAllWrong_Parameterized(String current)
    {
        assertFalse("Checking " + current, Ex02_MatchingBracesChecker.checkMatchingBraces(current));
    }

    @ParameterizedTest
    @ValueSource(strings = { "()", "()[]{}", "[((()[]{}))]" })
    public void testCheckMatchingBracesAllOk_Parameterized(String current)
    {
        assertTrue("Checking " + current, Ex02_MatchingBracesChecker.checkMatchingBraces(current));
    }
    
    // Option, andere Variante klarer
    
    @ParameterizedTest
    @CsvSource({ "(), true", "()[]{}, true", "[()[]{}))], false" })
    public void testCheckMatchingBracesAllOk_Parameterized(String current, boolean result)
    {
        assertEquals(result, Ex02_MatchingBracesChecker.checkMatchingBraces(current));
    }
}
