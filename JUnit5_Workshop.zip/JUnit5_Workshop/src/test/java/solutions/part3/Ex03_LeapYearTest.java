package solutions.part3;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import exercises.part3.Ex03_LeapYear;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex03_LeapYearTest 
{
    @ParameterizedTest
    @ValueSource(ints = { 2000, 2004, 2008, 2012, 2016, 2020 })
    public void testLeap(final int year)
    {
        assertTrue(Ex03_LeapYear.isLeap(year));
    }

    @ParameterizedTest
    @ValueSource(ints = { 1700, 1800, 1900 })
    public void testSakular(final int year)
    {
        assertFalse(Ex03_LeapYear.isLeap(year));
    }
    
    
	@ParameterizedTest(name = "isLeap({0}) => {2}, Hinweis: {1}")
	@CsvSource({ "1900, Säkulär, false",
			"2000, Säkular (aber 400er Regel), true",
			"2020, jedes 4. Jahr, true" })
	void testIsLeap(int year, String hint, boolean expected) {

		final boolean result = Ex03_LeapYear.isLeap(year);

		assertEquals(expected, result);
	}

	@ParameterizedTest(name = "Schaltjahr {0}? {2}, Hinweis: {1}")
	@CsvSource({ "1900, Säkulär, \u274C, false",
			"2000, Säkular (aber 400er Regel), \u2705, true",
			"2020, jedes 4. Jahr, \u2705, true" })
	void testIsLeapNice(int year, String hint, String resultNice, boolean expected) {
		final boolean result = Ex03_LeapYear.isLeap(year);

		assertEquals(expected, result);
	}	
}
