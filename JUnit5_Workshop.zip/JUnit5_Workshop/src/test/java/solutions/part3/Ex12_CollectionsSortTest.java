package solutions.part3;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import domain.Person;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex12_CollectionsSortTest
{
    private static final List<Person> persons    = new ArrayList<>(Arrays
                    .asList(new Person("Mike", LocalDate.of(1971, 2, 7), "Bremen"),
                            new Person("Tim", LocalDate.of(1971, 3, 27), "Kiel"),
                            new Person("Peter", LocalDate.of(1999, 12, 15), "Hamburg"),
                            new Person("Tom", LocalDate.of(2011, 11, 11), "Aachen")));

    private static final Comparator<Person>  byName     = Comparator.comparing(Person::getName);

    private static final Comparator<Person>  byBirthday = Comparator.comparing(Person::getDateOfBirth);

    private static final Comparator<Person>  byCity     = Comparator.comparing(Person::getHomeTown);

    @Test
    void testSortedbyName()
    {
        final List<Person> expectedSortedByName = Arrays
                        .asList(new Person("Mike", LocalDate.of(1971, 2, 7), "Bremen"),
                                new Person("Peter", LocalDate.of(1999, 12, 15), "Hamburg"),
                                new Person("Tim", LocalDate.of(1971, 3, 27), "Kiel"),
                                new Person("Tom", LocalDate.of(2011, 11, 11), "Aachen"));
        persons.sort(byName);

        assertEquals(expectedSortedByName, persons);
        assertIterableEquals(expectedSortedByName, persons);
    }

    @Test
    void testSortedbyNameAssertJ()
    {
        persons.sort(byName);

        assertThat(persons).isSortedAccordingTo(byName);
    }
    
    // Generische Lösung
    
    @ParameterizedTest
    @MethodSource("myComparators")
    void testSortedbyXyzAssertJ(Comparator<Person> comp)
    {
        persons.sort(comp);

        assertThat(persons).isSortedAccordingTo(comp);
    }
    
    static Stream<Arguments> myComparators()
    {
        return Stream.of(Arguments.of(byName), 
                         Arguments.of(byBirthday), 
                         Arguments.of(byCity));
    }

    
    @Test
    void testSortedbyCity()
    {
        final List<Person> expectedSortedByCity = Arrays.asList(new Person("Tom", LocalDate.of(2011, 11, 11), "Aachen"),
                                                                new Person("Mike", LocalDate.of(1971, 2, 7), "Bremen"),
                                                                new Person("Peter", LocalDate.of(1999, 12, 15),
                                                                           "Hamburg"),
                                                                new Person("Tim", LocalDate.of(1971, 3, 27), "Kiel"));
        persons.sort(byCity);

        assertEquals(expectedSortedByCity, persons);
        assertIterableEquals(expectedSortedByCity, persons);
    }

    @Test
    void testSortedbyCityAssertJ()
    {
        persons.sort(byCity);

        assertThat(persons).isSortedAccordingTo(byCity);
    }

    @Test
    void testSortedbyBirthday()
    {
        final List<Person> expectedSortedByBirthday = Arrays
                        .asList(new Person("Mike", LocalDate.of(1971, 2, 7), "Bremen"),
                                new Person("Tim", LocalDate.of(1971, 3, 27), "Kiel"),
                                new Person("Peter", LocalDate.of(1999, 12, 15), "Hamburg"),
                                new Person("Tom", LocalDate.of(2011, 11, 11), "Aachen"));
        persons.sort(byBirthday);

        assertEquals(expectedSortedByBirthday, persons);
        assertIterableEquals(expectedSortedByBirthday, persons);
    }

    @Test
    void testSortedbyBirthdayAssertJ()
    {
        persons.sort(byBirthday);

        assertThat(persons).isSortedAccordingTo(byBirthday);
    }
}               