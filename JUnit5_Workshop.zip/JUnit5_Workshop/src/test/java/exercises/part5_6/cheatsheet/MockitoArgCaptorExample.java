package exercises.part5_6.cheatsheet;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MockitoArgCaptorExample
{
    @Test
    public void testArgCapture()
    {
        // Arrange
        final Greeting greeting = mock(Greeting.class);
        when(greeting.greet(anyString())).thenReturn("value");
    
        // Act
        final Application app = new Application(greeting);
        app.generateMsg("One");
        app.generateMsg("Two");
        app.generateMsg("Three");
    
        // Assert
        final ArgumentCaptor<String> argumentCaptor = 
                                     ArgumentCaptor.forClass(String.class);
        verify(greeting, times(3)).greet(argumentCaptor.capture());
    
        final List<String> passedValues = argumentCaptor.getAllValues();
        assertEquals("One", passedValues.get(0));
        assertEquals("Two", passedValues.get(1));
        assertEquals("Three", passedValues.get(2));
    }
}