package exercises.part5_6.cheatsheet;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MockitoHelloWorldExample
{
    @Test
    public void testGreetingReturnValue()
    {
        // Arrange
        final Greeting greeting = mock(Greeting.class);
        when(greeting.greet()).thenReturn("Hello Mockito");
    
        // Act
        final String result = greeting.greet();
    
        // Assert
        assertEquals("Hello Mockito", result);
    }
    
    private class Greeting
    {
        public String greet()
        {
            return "Hello world!";
        }
    }
}
