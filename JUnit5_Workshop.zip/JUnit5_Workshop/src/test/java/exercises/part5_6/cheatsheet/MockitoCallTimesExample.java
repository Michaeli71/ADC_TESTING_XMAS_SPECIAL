package exercises.part5_6.cheatsheet;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.atMost;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

import org.mockito.Mockito;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MockitoCallTimesExample
{
    @Test
    public void testGreetingCallCount()
    {
        // Arrange
        final Greeting greeting = mock(Greeting.class);
        when(greeting.greet()).thenReturn("Hello Mockito1", "Hello Mockito2");

        // Act
        final String result1 = greeting.greet();
        final String result2 = greeting.greet();
        final String result3 = greeting.greet();

        // Assert
        assertEquals("Hello Mockito1", result1);
        assertEquals("Hello Mockito2", result2);
        assertEquals("Hello Mockito2", result3);

        Mockito.verify(greeting, atLeast(1)).greet();
        Mockito.verify(greeting, atMost(3)).greet();
        Mockito.verify(greeting, times(3)).greet();
        // Mockito.verifyNoMoreInteractions(greeting);
    }

    private class Greeting
    {
        public String greet()
        {
            return "Hello world!";
        }

        public String additional()
        {
            return "Hello world!";
        }
    }
}
