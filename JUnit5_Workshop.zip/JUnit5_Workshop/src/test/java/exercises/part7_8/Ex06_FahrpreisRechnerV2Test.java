package exercises.part7_8;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex06_FahrpreisRechnerV2Test
{
    private static final int grundpreis = 3_50;

    private static final int centProKM  = 2_10;

    @Test
    public void TF1()
    {
        final int preis = FahrpreisRechnerV2.fahrpreisImproved(grundpreis, centProKM, 60, true, true, false);

        assertEquals(14_510, preis);
    }

    @Test
    public void TF2()
    {
        final int preis = FahrpreisRechnerV2.fahrpreisImproved(grundpreis, centProKM, 60, true, false, false);

        assertEquals(14_210, preis);
    }
}
