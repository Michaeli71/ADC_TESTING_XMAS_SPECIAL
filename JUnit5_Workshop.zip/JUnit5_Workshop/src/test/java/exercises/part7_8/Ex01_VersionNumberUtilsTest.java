package exercises.part7_8;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex01_VersionNumberUtilsTest
{
    @Test
    void test()
    {
        String v1 = "1.11.17";
        String v2 = "2.3.5";
        String v3 = "2.4";
        String v4 = "3.1"; // 3.5
        String v5 = "3.1.72";

        // assertEquals(0, Ex01_VersionNumberUtils.compareVersions(v1, v1));
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v1, v1) == 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v1, v2) < 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v2, v1) > 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v2, v3) < 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v3, v4) < 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v3, v1) > 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v4, v5) < 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v5, v4) > 0);
    }

    @Test
    void assertTrueForever()
    {
        final Ex02_Student mike = new Ex02_Student(1, "Mike", 97);
        final Ex02_Student sameMike = mike;
        final Ex02_Student otherMike = new Ex02_Student(1, "Mike", 97);
                  
        assertTrue(mike != null, "mike not null");
        assertTrue(mike == sameMike, "same obj");
        assertTrue(mike.equals(otherMike), "same content");
    }
        
    // => Test Smells entfernen

    // TODO
}
