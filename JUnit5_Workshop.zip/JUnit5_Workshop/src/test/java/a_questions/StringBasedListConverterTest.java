package a_questions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.converter.ConvertWith;
import org.junit.jupiter.params.converter.SimpleArgumentConverter;
import org.junit.jupiter.params.provider.CsvSource;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2021 by Michael Inden 
 */
public class StringBasedListConverterTest
{
    @ParameterizedTest
    @CsvSource({ "[1|2|3], 1, 3, [1|2|3]", 
                 "[7|2|1|49|14], 1, 49, [1|2|7|14|49]" })
// Alternative mit delimiter = "|", aber spezielle, etwas mehr Anpassungenen nötig 
//    @CsvSource(value={ "[1,2,3] | 1 | 3 | [1,2,3]", 
//    "[7|2|1|49|14], 1, 49, [1|2|7|14|49]" }, delimiter = "|")   
    // [1,2,3,7,9] => List<Integer>
    void sortIntegerTest(@ConvertWith(ListIntegerConverter.class) List<Integer> inputs,
                         int expectedFirstValue, int expectectLastValue,
                         @ConvertWith(ListIntegerConverter.class) List<Integer> expectedSorted)
    {                
    	inputs.sort(Comparator.naturalOrder());
    	List<Integer> sorted = inputs;
    	        
        assertEquals(expectedFirstValue, sorted.get(0));
        assertEquals(expectectLastValue, sorted.get(sorted.size() - 1));
        
        assertEquals(expectedSorted, sorted);
    }

    @ParameterizedTest
    @CsvSource({ "[Lilija|Anne|Sophie|Julia], [Anne|Julia|Lilija|Sophie]", 
                 "[Tom|Jim|Stefan|Mike], [Jim|Mike|Stefan|Tom]" })    
    // [1,2,3,7,9] => List<Integer>
    void sortStringTest(@ConvertWith(ListStringConverter.class) List<String> inputs,
                        @ConvertWith(ListStringConverter.class) List<String> expectedSorted)
    {                
    	inputs.sort(Comparator.naturalOrder());
    	List<String> sorted = inputs;
    	                
        assertEquals(expectedSorted, sorted);
    }
    
    
    static class ListIntegerConverter extends SimpleArgumentConverter
    {
        @Override
        public List<Integer> convert(Object source, Class<?> targetType)
        {
            // strip of [ .. ]
            String strSource = (String)source;
            if (strSource.startsWith("[") && strSource.endsWith("]"))
            {            
	            String[] values = extractValues(strSource.substring(1, strSource.length() - 1));
	            
	            return Arrays.stream(values).
	            		      mapToInt(val -> Integer.valueOf(val)).
	            		      boxed().
	            		      collect(Collectors.toList());
            }
            else
            {
            	throw new IllegalArgumentException("wrong data format, missing braces [ <values> ]");
            }
        }
    }

    
    static class ListStringConverter extends SimpleArgumentConverter
    {
        @Override
        public List<String> convert(Object source, Class<?> targetType)
        {
            // strip of [ .. ]
            String strSource = (String)source;
            if (strSource.startsWith("[") && strSource.endsWith("]"))
            {            
	            String[] values = extractValues(strSource.substring(1, strSource.length() - 1));
	            
	            return Arrays.stream(values).
	            		      collect(Collectors.toList());
            }
            else
            {
            	throw new IllegalArgumentException("wrong data format, missing braces [ <values> ]");
            }
        }
    }

    
    private static String[] extractValues(String sourceAsText)
    {
        String sourceAsTextNoSpaces = sourceAsText.replaceAll("(\\s)*", "");
        String[] values = sourceAsTextNoSpaces.split("\\|");
        
        return values;
    }
}
