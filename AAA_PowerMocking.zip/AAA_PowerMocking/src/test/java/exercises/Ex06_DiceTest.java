package exercises;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ Ex06_Dice.class })
public class Ex06_DiceTest
{
    @Test
    public void shouldAddUpDiceRollsCorrectly()
    {
        // TODO: Wertefolge Math.random() => (0.2,0.4,0.6,0.8,1.0)
        
        Ex06_Dice dice = new Ex06_Dice();

        assertEquals(14, dice.sumOfNumDiceRolls(4));
        assertEquals(70, dice.sumOfNumDiceRolls(10));        
    }
    
    @Test
    public void shouldAddUpDiceRollsCorrectly_V2() throws Exception
    {
        // TODO

        Ex06_Dice dice = new Ex06_Dice();

        assertAll(() -> assertEquals(36, dice.roll10()), 
                  () -> assertEquals(20, dice.roll10()));
    }
}