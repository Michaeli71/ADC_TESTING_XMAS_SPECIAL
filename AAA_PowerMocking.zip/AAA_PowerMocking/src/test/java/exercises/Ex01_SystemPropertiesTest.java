package exercises;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
// TODO
public class Ex01_SystemPropertiesTest
{
    @Test
    public void access_system_property()
    {
        // ARRANGE
        final Ex01_SystemProperties sut = new Ex01_SystemProperties();
        // TODO

        // ACT
        String result1 = sut.getSystemProperty("ABC");
        String result2 = sut.getSystemProperty("XYZ");

        // ASSERT
        assertAll(() -> assertEquals("POWER-MOCKED", result1),
                  () -> assertNull(result2));
    }
}
