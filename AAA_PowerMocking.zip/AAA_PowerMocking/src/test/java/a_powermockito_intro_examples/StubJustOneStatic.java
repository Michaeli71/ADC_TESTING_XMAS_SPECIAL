package a_powermockito_intro_examples;

import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
class ClassWithStatics
{
    public static String getString()
    {
        return "String";
    }

    public static int getInt()
    {
        return 1;
    }
}

@RunWith(PowerMockRunner.class)
@PrepareForTest(ClassWithStatics.class)
public class StubJustOneStatic
{
    @Test
    public void test()
    {
        PowerMockito.mockStatic(ClassWithStatics.class);
        when(ClassWithStatics.getString()).thenReturn("Hello!");

        System.out.println("String: " + ClassWithStatics.getString());
        System.out.println("Int: " + ClassWithStatics.getInt());
    }
}