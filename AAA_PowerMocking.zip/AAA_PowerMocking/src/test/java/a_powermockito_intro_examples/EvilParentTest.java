package a_powermockito_intro_examples;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.powermock.api.support.membermodification.MemberMatcher.constructor;
import static org.powermock.api.support.membermodification.MemberModifier.suppress;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(ExampleWithEvilParent.class)
public class EvilParentTest {

	@Test
	public void testSuppressConstructorOfEvilParent() throws Exception {
		suppress(constructor(EvilParent.class));
		final String message = "myMessage";
		ExampleWithEvilParent tested = new ExampleWithEvilParent(message);
		assertEquals(message, tested.getMessage());
	}
}
