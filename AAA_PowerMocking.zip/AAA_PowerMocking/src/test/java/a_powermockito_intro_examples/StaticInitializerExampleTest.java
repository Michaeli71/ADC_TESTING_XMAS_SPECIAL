package a_powermockito_intro_examples;

import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.suppress;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
public class StaticInitializerExampleTest
{    
    @SuppressStaticInitializationFor("a_powermockito_intro_examples.StaticInitializerExample")
    @Test 
    public void testWithoutStaticInitializerd() 
    {
        StaticInitializerExample instance = new StaticInitializerExample();
    }
    
    @PrepareForTest(StaticInitializerExample.class)
    @Test 
    public void testWithoutFaultyMethodCall() 
    {
        suppress(method(DBUtils.class, "initialize"));
    
        StaticInitializerExample instance = new StaticInitializerExample();
    }
}
