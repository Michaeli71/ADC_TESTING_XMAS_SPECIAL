package a_powermockito_intro_examples;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(CalculatorService.class)
public class CalculatorTest
{
    @Test
    public void multiply_instead_of_add()
    {
        // ARRANGE
        final Calculator calc = new Calculator();
        PowerMockito.mockStatic(CalculatorService.class);
        PowerMockito.when(CalculatorService.add(1, 1)).thenReturn(1);
        PowerMockito.when(CalculatorService.add(5, 2)).thenReturn(10);

        // ACT
        int result1 = calc.add(1, 1);
        int result2 = calc.add(5, 2);

        // ASSERT
        assertEquals(1, result1);
        assertEquals(10, result2);
    }

    @Test
    public void special_handling_of_invalid_input()
    {
        // ARRANGE
        final Calculator calc = new Calculator();
        PowerMockito.mockStatic(CalculatorService.class);
        
        PowerMockito.when(CalculatorService.add(-1, -1)).thenThrow(new ArithmeticException());
        
        //PowerMockito.doThrow(new ArithmeticException()).when(CalculatorService.class);
        //CalculatorService.add(-1, -1);

        // ACT & ASSERT
        assertThrows(ArithmeticException.class, () -> calc.add(-1, -1));
    }

    @Test
    public void verify_static_method_is_called()
    {
        // ARRANGE
        final Calculator calc = new Calculator();
        PowerMockito.mockStatic(CalculatorService.class);
        PowerMockito.when(CalculatorService.add(1, 1)).thenReturn(1);
        PowerMockito.when(CalculatorService.add(5, 2)).thenReturn(10);

        // ACT
        calc.add(1, 1);

        // ASSERT / VERIFY
        PowerMockito.verifyStatic(CalculatorService.class);
        CalculatorService.add(1, 1);
    }
}