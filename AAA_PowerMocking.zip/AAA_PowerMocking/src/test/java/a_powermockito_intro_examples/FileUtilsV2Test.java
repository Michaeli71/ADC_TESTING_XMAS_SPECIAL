package a_powermockito_intro_examples;

import java.io.File;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
public class FileUtilsV2Test
{
    @Test
    @PrepareForTest(FileUtilsV2.class)
    public void testCallArgumentInstance() throws Exception
    {
        File file = PowerMockito.mock(File.class);
        File filePY = PowerMockito.mock(File.class);

        PowerMockito.whenNew(File.class).withArguments("TESTFILE").thenReturn(file);
        // PowerMockito.whenNew(File.class).withAnyArguments().thenReturn(file);
        PowerMockito.when(file.exists()).thenReturn(true);
        
        PowerMockito.whenNew(File.class).withArguments("RECURSION.PY").thenReturn(filePY);
        PowerMockito.when(filePY.exists()).thenReturn(false);            
        
        // ACT
        FileUtilsV2 demo = new FileUtilsV2();
        boolean callArgumentInstance = demo.checkExistance("TESTFILE");
        
        // ASSERT
        Assert.assertTrue(callArgumentInstance);
    }
}