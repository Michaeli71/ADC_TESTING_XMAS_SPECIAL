package solutions;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import exercises.Ex08_PizzaService;
import exercises.SmsNotificationService;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
public class Ex08_PizzaServiceTest
{
    @Test
    @PrepareForTest({SmsNotificationService.class, Ex08_PizzaService.class})
    public void orderPizza_should_send_sms_powermockito_based() throws Exception
    {
        // Arrange
    	SmsNotificationService mockSmsService = PowerMockito.mock(SmsNotificationService.class);
        PowerMockito.whenNew(SmsNotificationService.class).withAnyArguments().thenReturn(mockSmsService);

        // wir müssen den Swing Call ausschalten
        //PowerMockito.doNothing().when(mockSmsService).notify(Mockito.anyString());
        
        // Alternative mit Answer, um zusätzliche Aktionen auszuführen        
        Answer answer = new Answer() {
            @Override
			public Void answer(InvocationOnMock invocation) throws Throwable {
                System.out.println("NOT CALLING SWING ANYMORE");
                return null;
            }
        };               
        PowerMockito.doAnswer(answer).when(mockSmsService).notify(Mockito.anyString());
        
        final Ex08_PizzaService service = new Ex08_PizzaService();

        // Act
        service.orderPizza("Diavolo");
        service.orderPizza("Surprise");

        // Assert
        Mockito.verify(mockSmsService, Mockito.times(2)).notify(Mockito.anyString());
    }
}

