package solutions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.time.LocalTime;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import exercises.Ex07_MessageIdAndUrlUtil;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(Ex07_MessageIdAndUrlUtil.class)
public class Ex07_SpecialMockingStaticsAndConstructorsTest
{
    @Test
    public void simulate_unknown_host_generate_random_uuid() throws UnknownHostException
    {
        // ARRANGE
        UUID id = UUID.randomUUID();
     
        PowerMockito.mockStatic(InetAddress.class);
        PowerMockito.when(InetAddress.getLocalHost()).thenThrow(UnknownHostException.class);

        PowerMockito.mockStatic(UUID.class);        
        PowerMockito.when(UUID.randomUUID()).thenReturn(id);
        
        // ACT
        String msgId = Ex07_MessageIdAndUrlUtil.randomMessageId();
        
        // ASSERT
        assertEquals(id.toString(), msgId);
    }

    @Test
    public void url_remapped_to_localhost() throws MalformedURLException, Exception
    {
        // ARRANGE
        PowerMockito.mockStatic(URL.class);

        URL mockedURL = PowerMockito.mock(URL.class);
        PowerMockito.when(mockedURL.getHost()).thenReturn("localhost");
        PowerMockito.whenNew(URL.class).withAnyArguments().thenReturn(mockedURL);

        // ACT
        URL url = Ex07_MessageIdAndUrlUtil.getUrl();

        // ASSERT
        assertEquals("localhost", url.getHost());
    }
    
    @Test
    @PrepareForTest({LocalTime.class, Ex07_MessageIdAndUrlUtil.class})
    public void get_fixed_timestamp() 
    {
        // ARRANGE
        LocalTime specialLocalTime = LocalTime.of(9, 2, 51);

        PowerMockito.mockStatic(LocalTime.class);
        PowerMockito.when(LocalTime.now()).thenReturn(specialLocalTime);

        // ACT
        String timeStamp = Ex07_MessageIdAndUrlUtil.currentTime();

        // ASSERT
        assertEquals("09:02:51", timeStamp);
    }
}