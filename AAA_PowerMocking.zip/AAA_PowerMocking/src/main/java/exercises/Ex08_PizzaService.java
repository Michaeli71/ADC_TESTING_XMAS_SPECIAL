package exercises;
/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex08_PizzaService
{
    private final SmsNotificationService notificationService;

    public Ex08_PizzaService()
    {
        notificationService = new SmsNotificationService();
        System.out.println(notificationService);
    }

    public void orderPizza(final String name)
    {
        notificationService.notify("Pizza " + name + " wird in Kürze geliefert.");
    }
}