package exercises;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex03_FigureFactory
{
    public enum FigureTypes
    {
        RECT, LINE, OVAL, CIRCLE, HEXAGON
    }
    
    public static String getFigure(FigureTypes type)
    {
        if (type == FigureTypes.RECT)
            return "RECT";
        if (type == FigureTypes.LINE)
            return "LINE";

        throw new IllegalStateException("Unsupported Type: " + type);
    } 
}