package exercises;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex05_SubClass extends Ex05_SuperClass
{
    @Override
    public String someMethod()
    {
        super.someMethod();
        return "RESULT FROM CHILD";
    }
}