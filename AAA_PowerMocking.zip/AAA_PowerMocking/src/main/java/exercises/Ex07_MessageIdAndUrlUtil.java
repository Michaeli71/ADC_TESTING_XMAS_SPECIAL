package exercises;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.time.LocalTime;
import java.util.UUID;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex07_MessageIdAndUrlUtil
{
    public static String randomMessageId()
    {
        try
        {
            return InetAddress.getLocalHost().getHostAddress();
        }
        catch (UnknownHostException e)
        {
            return generateUUID();
        }
    }

    public static URL getUrl() throws MalformedURLException
    {
        return new URL("SILLY_INVALID");
    }
    
    private static final String generateUUID()
    {
        return UUID.randomUUID().toString();
    }

    public static final String currentTime()
    {
        return LocalTime.now().toString();
    }
}
