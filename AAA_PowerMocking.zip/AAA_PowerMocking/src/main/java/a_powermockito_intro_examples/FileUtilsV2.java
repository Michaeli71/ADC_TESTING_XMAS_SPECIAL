package a_powermockito_intro_examples;

import java.io.File;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class FileUtilsV2
{
    public boolean checkExistance(String path)
    {
        final File file = new File(path);
        return file.exists();
    }
}