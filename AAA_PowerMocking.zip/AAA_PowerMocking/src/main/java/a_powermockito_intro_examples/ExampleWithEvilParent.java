package a_powermockito_intro_examples;

// https://github.com/powermock/powermock/wiki/Suppress-Unwanted-Behavior
public class ExampleWithEvilParent extends EvilParent {

	private final String message;

	public ExampleWithEvilParent(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}