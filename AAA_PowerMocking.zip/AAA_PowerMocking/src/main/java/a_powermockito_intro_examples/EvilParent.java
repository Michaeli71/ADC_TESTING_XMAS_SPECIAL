package a_powermockito_intro_examples;

//https://github.com/powermock/powermock/wiki/Suppress-Unwanted-Behavior
public class EvilParent {

	public EvilParent() {
		System.out.println("System.loadLibrary(\"evil.dll\")");
	}
}