package mutation;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class FirstMutationExample
{
    public static String buildMessage(final int value)
    {
        if (value >= 0)
        {
            return "almost positive";
        }
        else
        {
            return "negative";
        }
    }
}
